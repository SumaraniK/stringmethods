import React, { useRef } from 'react'

function StringMethods() {
    let string = "String methods help you to work with strings.";
    let charAtRef = useRef();
    let charAtResultRef = useRef();
    let lengthRef = useRef();
    let lengthResultRef = useRef();
    let concatRef = useRef();
    let concatResultRef = useRef();
    let startsWithRef = useRef();
    let startsWithResultRef = useRef();
    let endsWithRef = useRef();
    let endsWithResultRef = useRef();
    let stringCharCodeRef = useRef();
    let stringCharCodeResultRef = useRef();
    let sliceRef = useRef();
    let sliceResultRef = useRef();
    let splitRef = useRef();
    let splitResultRef = useRef();
    let searchRef = useRef();
    let searchResultRef = useRef();
    let stringRef = useRef();
    let stringResultRef = useRef();
    let indexOfRef = useRef();
    let indexOfResultRef = useRef();
    let lastIndexOfRef = useRef();
    let lastIndexOfResultRef = useRef();
    let upperCaseRef = useRef();
    let upperCaseResultRef = useRef();
    let lowerCaseRef = useRef();
    let lowerCaseResultRef = useRef();
    let trimRef = useRef();
    let trimResultRef = useRef();




    let onFocus = (inputRef) => {
        inputRef.current.style.backgroundColor = "#C70039";
    };
    let onBlur = (inputRef) => {
        inputRef.current.style.backgroundColor = "Turquoise";
    };
    let length = () => {
        let string = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        let length = string.length;
        let str = lengthRef.current.value;
        let len = str.length;
        lengthResultRef.current.innerHTML = len;
        console.log(length);
    }
    let charAt = () => {
        let text = string.charAt(charAtRef.current.value);
        charAtResultRef.current.innerHTML = text;
        console.log(text);
        
    }
    let concat = () => {
        let string1 = "JavaScript treats primitive values as objects when executing methods and properties.";
        let str = string.concat(string1);
        let result = string.concat(concatRef.current.value);
        concatResultRef.current.innerHTML = result;
        console.log(str);
    }
    let startsWith = () => {
        let str = string.startsWith("String");
        console.log(str);
        let result = string.startsWith(startsWithRef.current.value);
        startsWithResultRef.current.innerHTML = result;

    }
    let endsWith = () => {
        let str = string.endsWith(".");
        console.log(str);
        let result = string.endsWith(endsWithRef.current.value);
        endsWithResultRef.current.innerHTML = result;

    }
    let indexOf = () => {
        //let str = searchRef.current.value;
        let result = string.indexOf(indexOfRef.current.value);
        console.log(result);
        indexOfResultRef.current.innerHTML = result;
        let fString = string.indexOf("String");
        console.log(fString);
    }
    let lastIndexOf = () => {
        //let str = searchRef.current.value;
        let result = string.lastIndexOf(lastIndexOfRef.current.value);
        console.log(result);
        lastIndexOfResultRef.current.innerHTML = result;
        let fString = string.indexOf("String");
        console.log(fString);
    }
    let charCodeAt = () => {
        let str = string.charCodeAt(9);
        console.log(str);
        let result = string.charCodeAt(stringCharCodeRef.current.value);
        stringCharCodeResultRef.current.innerHTML = result;
        // for (let i=0; i<=130;i++){
        //     console.log(String.fromCharCode(i));
        // }
    }
    let search = () => {
        let str = searchRef.current.value;
        let result = str.search("string");
        let fString = string.search("string");
        console.log(fString);
        searchResultRef.current.innerHTML = result;

    }
    let split = () => {
        let str = splitRef.current.value;
        let result = str.split("");
        let fString = string.split("");
        console.log(fString);
        splitResultRef.current.innerHTML = result;
    }
    let slice = () => {
        let str = sliceRef.current.value;
        let result = str.slice(2,8);
        let fString = string.slice(0,9);
        console.log(fString);
        sliceResultRef.current.innerHTML = result;
    }
    let substring = () => {
        let str = stringRef.current.value;
        let result = str.substring(3,5);
        let fString = string.substring(4,9);
        let sString = string.substr(4,9);
        console("substr string is ", sString)
        console.log(fString);
        stringResultRef.current.innerHTML = result;
    }
    let toUpperCase = () => {
        let str = upperCaseRef.current.value;
        let result = str.toUpperCase();
        let fString = string.toUpperCase();
        console.log(fString);
        upperCaseResultRef.current.innerHTML = result;
    }
    let toLowerCase = () => {
        let str = lowerCaseRef.current.value;
        let result = str.toLowerCase();
        let fString = string.toLowerCase();
        console.log(fString);
        lowerCaseResultRef.current.innerHTML = result;
    }
    let trim = () => {
        //let str = "                 A JavaScript string is zero or more characters written inside quotes.                    "
        let str = trimRef.current.value;
        let result =  str.trim();
        console.log(result);
        trimResultRef.current.innerHTML = result;
        let result1 = str.trimEnd();
        console.log(result1);
        let result2 = str.trimStart();
        console.log(result2);
    }
  return (
    <div>
        <h1>JavaScript String Methods</h1>    
        <div className='stringMethods'>   
            <div className = "button">
                <h4>CharAt</h4>
                <input type="text" ref={charAtRef} 
                onFocus={() => {onFocus(charAtRef);}}
                onBlur={() => {onBlur(charAtRef, charAtResultRef);}}>
                </input>
                <button type = "button" className = "button1"  onClick={() => {charAt();}}> charAt </button><br></br>
                <span ref={charAtResultRef}></span>
            </div>
            <span ref={charAtResultRef}></span>
            <div className = "button">
                <h4>Length</h4>
                <input type="text" ref={lengthRef} 
                onFocus={() => {onFocus(lengthRef);}}
                onBlur={() => {onBlur(lengthRef, lengthResultRef);}}>
                </input>
                <button type = "button" className = "button1"  onClick={() => {length();}}> length </button><br></br>
                <span ref={lengthResultRef}></span>
            </div>
            
            <div className = "button">
                <h4>Concat</h4>
                <input type="text" ref={concatRef} 
                onFocus={() => {onFocus(concatRef);}}
                onBlur={() => {onBlur(concatRef, concatResultRef);}}>
                </input>
                <button type = "button" className = "button1"  onClick={() => {concat();}}> concat </button><br></br>
                <span ref={concatResultRef}></span>
            </div>
            
            <div className = "button">
                <h4>EndsWith</h4>
                <input type="text" ref={endsWithRef} 
                onFocus={() => {onFocus(endsWithRef);}}
                onBlur={() => {onBlur(endsWithRef, endsWithResultRef);}}>
                </input>
                <button type = "button" className = "button1"  onClick={() => {endsWith();}}> endsWith </button><br></br>
                <span ref={endsWithResultRef}></span>
            </div>
            
            <div className = "button">
                <h4>IndexOf</h4>
                <input type="text" ref={indexOfRef} 
                onFocus={() => {onFocus(indexOfRef);}}
                onBlur={() => {onBlur(indexOfRef, indexOfResultRef);}}>
                </input>
                <button type = "button" className = "button1"  onClick={() => {indexOf();}}> indexOf </button><br></br>
                <span ref={indexOfResultRef}></span>
            </div>
            
            <div className = "button">
                <h4>LastIndexOf</h4>
                <input type="text" ref={lastIndexOfRef} 
                onFocus={() => {onFocus(lastIndexOfRef);}}
                onBlur={() => {onBlur(lastIndexOfRef, lastIndexOfResultRef);}}>
                </input>
                <button type = "button" className = "button1"  onClick={() => {lastIndexOf();}}> LastIndexOf </button><br></br>
                <span ref={lastIndexOfResultRef}></span>
            </div>
            
            <div className = "button">
                <h4>StartsWith</h4>
                <input type="text" ref={startsWithRef} 
                onFocus={() => {onFocus(startsWithRef);}}
                onBlur={() => {onBlur(startsWithRef, startsWithResultRef);}}>
                </input>
                <button type = "button" className = "button1"  onClick={() => {startsWith();}}> StartsWith </button><br></br>
                <span ref={startsWithResultRef}></span>
            </div>
            
            <div className = "button">
                <h4>CharCodeAt</h4>
                <input type="text" ref={stringCharCodeRef} 
                    onFocus={() => {onFocus(stringCharCodeRef);}}
                    onBlur={() => {onBlur(stringCharCodeRef, stringCharCodeResultRef);}}>
                </input>
                <button type = "button" className = "button1"  onClick={() => {charCodeAt();}}> CharCodeAt </button><br></br>
                <span ref={stringCharCodeResultRef}></span>
            </div>
            
            <div className = "button">
                <h4>Search</h4>
                <input type="text" ref={searchRef} 
                    onFocus={() => {onFocus(searchRef);}}
                    onBlur={() => {onBlur(searchRef, searchResultRef);}}>
                </input>
                <button type = "button" className = "button1"  onClick={() => {search();}}> search </button><br></br>
                <span ref={searchResultRef}></span>
            </div>
            
            <div className = "button">
                <h4>Split</h4>
                <input type="text" ref={splitRef} 
                    onFocus={() => {onFocus(splitRef);}}
                    onBlur={() => {onBlur(splitRef, splitResultRef);}}>
                </input>
                <button type = "button" className = "button1"  onClick={() => {split();}}> split </button><br></br>
                <span ref={splitResultRef}></span>
            </div>
            
            <div className = "button">
                <h4>Slice</h4>
                <input type="text" ref={sliceRef} 
                    onFocus={() => {onFocus(sliceRef);}}
                    onBlur={() => {onBlur(sliceRef, sliceResultRef);}}>
                </input>
                <button type = "button" className = "button1"  onClick={() => {slice();}}> slice </button><br></br>
                <span ref={sliceResultRef}></span>
            </div>
            
            <div className = "button">
                <h4>SubString</h4>
                <input type="text" ref={stringRef} 
                    onFocus={() => {onFocus(stringRef);}}
                    onBlur={() => {onBlur(stringRef, stringResultRef);}}>
                </input>
                <button type = "button" className = "button1"  onClick={() => {substring();}}> substring </button><br></br>
                <span ref={stringResultRef}></span>
            </div>
            
            <div className = "button">
                <h4>ToUpperCase</h4>
                <input type="text" ref={upperCaseRef} 
                    onFocus={() => {onFocus(upperCaseRef);}}
                    onBlur={() => {onBlur(upperCaseRef, upperCaseResultRef);}}>
                </input>
                <button type = "button" className = "button1"  onClick={() => {toUpperCase();}}> toUpperCase </button><br></br>
                <span ref={upperCaseResultRef}></span>
            </div>
            
            <div className = "button">
                <h4>TOLowerCase</h4>
                <input type="text" ref={lowerCaseRef} 
                    onFocus={() => {onFocus(lowerCaseRef);}}
                    onBlur={() => {onBlur(lowerCaseRef, lowerCaseResultRef);}}>
                </input>
                <button type = "button" className = "button1"  onClick={() => {toLowerCase();}}> toLowerCase </button><br></br>
                <span ref={lowerCaseResultRef}></span>
            </div>
            
            <div className = "button">
                <h4>Trim</h4>
                <input type="text" ref={trimRef} 
                    onFocus={() => {onFocus(trimRef);}}
                    onBlur={() => {onBlur(trimRef, trimResultRef);}}>
                </input>
                <button type = "button" className = "button1"  onClick={() => {trim();}}> trim </button><br></br>
                <span ref={trimResultRef}></span>
            </div>
            
        </div>
    </div>
  )
}

export default StringMethods
