import React, { useRef } from 'react'

function StringMethods1() {
    let string = "String methods help you to work with strings.";
    // let charAtResultRef = useRef();
    // let lengthResultRef = useRef();
    // let concatResultRef = useRef();
    // let startsWithResultRef = useRef();
    // let endsWithResultRef = useRef();
    // let stringCharCodeResultRef = useRef();
    // let sliceResultRef = useRef();
    // let splitResultRef = useRef();
    // let searchResultRef = useRef();
     let stringRef = useRef();
     let stringResultRef = useRef();
    // let indexOfResultRef = useRef();
    // let lastIndexOfResultRef = useRef();
    // let upperCaseResultRef = useRef();
    // let lowerCaseResultRef = useRef();
    // let trimResultRef = useRef();
    let onFocus = (inputRef) => {
        inputRef.current.style.backgroundColor = "#C70039";
    };
    let onBlur = (inputRef) => {
        inputRef.current.style.backgroundColor = "Turquoise";
    };
    let length = () => {
        let string = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        let length = string.length;
        let str = stringRef.current.value;
        let len = str.length;
        stringResultRef.current.innerHTML = len;
        console.log(length);
    }
    let charAt = () => {
        let text = string.charAt(stringRef.current.value);
        stringResultRef.current.innerHTML = text;
        console.log(text);
        
    }
    let concat = () => {
        let string1 = "JavaScript treats primitive values as objects when executing methods and properties.";
        let str = string.concat(string1);
        let result = string.concat(string1);
        stringResultRef.current.innerHTML = result;
        console.log(str);
    }
    let startsWith = () => {
        let str = string.startsWith("String");
        console.log(str);
        let result = string.startsWith("String");
        stringResultRef.current.innerHTML = result;

    }
    let endsWith = () => {
        let str = string.endsWith(".");
        console.log(str);
        let result = string.endsWith(".");
        stringResultRef.current.innerHTML = result;

    }
    let indexOf = () => {
        //let str = searchRef.current.value;
        let result = string.indexOf("String");
        console.log(result);
        stringResultRef.current.innerHTML = result;
        let fString = string.indexOf("String");
        console.log(fString);
    }
    let lastIndexOf = () => {
        //let str = searchRef.current.value;
        let result = string.lastIndexOf("String");
        console.log(result);
        stringResultRef.current.innerHTML = result;
        let fString = string.indexOf("String");
        console.log(fString);
    }
    let charCodeAt = () => {
        let str = string.charCodeAt(9);
        console.log(str);
        let result = string.charCodeAt(9);
        stringResultRef.current.innerHTML = result;
        // for (let i=0; i<=130;i++){
        //     console.log(String.fromCharCode(i));
        // }
    }
    let search = () => {
        let str = stringRef.current.value;
        let result = str.search("string");
        let fString = string.search("string");
        console.log(fString);
        stringResultRef.current.innerHTML = result;

    }
    let split = () => {
        let str = stringRef.current.value;
        let result = str.split("");
        let fString = string.split("");
        console.log(fString);
        stringResultRef.current.innerHTML = result;
    }
    let slice = () => {
        let str = stringRef.current.value;
        let result = str.slice(2,8);
        let fString = string.slice(0,9);
        console.log(fString);
        stringResultRef.current.innerHTML = result;
    }
    let substring = () => {
        let str = stringRef.current.value;
        let result = str.substring(3,5);
        let fString = string.substring(4,9);
        let sString = string.substr(4,9);
        console("substr string is ", sString)
        console.log(fString);
        stringResultRef.current.innerHTML = result;
    }
    let toUpperCase = () => {
        let str = stringRef.current.value;
        let result = str.toUpperCase();
        let fString = string.toUpperCase();
        console.log(fString);
        stringResultRef.current.innerHTML = result;
    }
    let toLowerCase = () => {
        let str = stringRef.current.value;
        let result = str.toLowerCase();
        let fString = string.toLowerCase();
        console.log(fString);
        stringResultRef.current.innerHTML = result;
    }
    let trim = () => {
        //let str = "                 A JavaScript string is zero or more characters written inside quotes.                    "
        let str = stringRef.current.value;
        let result =  str.trim();
        console.log(result);
        stringResultRef.current.innerHTML = result;
        let result1 = str.trimEnd();
        console.log(result1);
        let result2 = str.trimStart();
        console.log(result2);
    }
  return (
    <div>
        <h1>JavaScript String Methods</h1>    
        <div >   
            <div>
                <h4>CharAt</h4>
                <input type="text" ref={stringRef} size = "80" 
                onFocus={() => {onFocus(stringRef);}}
                onBlur={() => {onBlur(stringRef, stringResultRef);}}>
                </input><br></br>
                <button type="button" onClick={() => {charAt();}}> charAt </button>
                <span  ref={stringResultRef}></span>
                <button type="button" onClick={() => {length();}}> length </button>
                <span ref={stringResultRef}></span>
                <button type="button" onClick={() => {concat();}}> concat </button>
                <span ref={stringResultRef}></span>
                <button type="button" onClick={() => {startsWith();}}> StartsWith </button>
                <span ref={stringResultRef}></span>
                <button type="button" onClick={() => {endsWith();}}> endsWith </button>
                <span ref={stringResultRef}></span>
                <button type="button" onClick={() => {charCodeAt();}}> CharCodeAt </button>
                <span ref={stringResultRef}></span>
                <button type="button" onClick={() => {indexOf();}}> indexOf </button>
                <span ref={stringResultRef}></span>
                <button type="button" onClick={() => {lastIndexOf();}}> LastIndexOf </button>
                <span ref={stringResultRef}></span>
                <button type="button" onClick={() => {search();}}> search </button>
                <span ref={stringResultRef}></span>
                <button type="button" onClick={() => {split();}}> split </button>
                <span ref={stringResultRef}></span>
                <button type="button" onClick={() => {slice();}}> slice </button>
                <span ref={stringResultRef}></span>
                <button type="button" onClick={() => {substring();}}> substring </button>
                <span ref={stringResultRef}></span>
                <button type="button" onClick={() => {toUpperCase();}}> toUpperCase </button>
                <span ref={stringResultRef}></span>
                <button type="button" onClick={() => {toLowerCase();}}> toLowerCase </button>
                <span ref={stringResultRef}></span>
                <button type="button" onClick={() => {trim();}}> trim </button>
                <span ref={stringResultRef}></span>
            </div>

            
            
        </div>
    </div>
  )
}

export default StringMethods1
