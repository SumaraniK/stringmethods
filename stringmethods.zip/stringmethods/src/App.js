
import './App.css';
import StringMethods from './component/StringMethods';
import StringMethods1 from './component/StringMethods1';

function App() {
  return (
    <div className="App">
      <StringMethods></StringMethods>
      <StringMethods1></StringMethods1>
    </div>
  );
}

export default App;
